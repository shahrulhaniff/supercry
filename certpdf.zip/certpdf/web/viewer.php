<?php 
   //session_start();
   $certificateId   = $_GET['certificateId'];
   $fileId   = $_GET['fileId'];
   //$api   = $_GET['api'];
   //$api="http://18.136.211.207/";
   $api="https://ccheck.unisza.edu.my";
   
   $pdflink = $api.'api/v1/view/certificate?certificateId='.$certificateId.'&fileId='.$fileId;
   //$pdflink = "http://18.136.211.207/api/v1/view/certificate?certificateId=5dca656fc0d2666608c6ea59&fileId=5dca657ac0d2666608c6ea75";
?>
<!DOCTYPE html>

<html dir="ltr" mozdisallowselectionprint>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="google" content="notranslate">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>PDF.js viewer</title>


    <link rel="stylesheet" href="viewer.css">


<!-- This snippet is used in production (included from viewer.html) -->
<link rel="resource" type="application/l10n" href="locale/locale.properties">
<script src="../build/pdf.js"></script>


   <?php include "skrip.php"; ?>

  </head>
	<?php 
	//salah satu
	include "body.php"
	//include "body_yg_pdfjs.php";
	?>
  
</html>

